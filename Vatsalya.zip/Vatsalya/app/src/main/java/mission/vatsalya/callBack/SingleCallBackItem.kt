package mission.vatsalya.callBack

//interface SingleCallBackItem {
//    fun onClickItem(selectedItem: IdAndName)
//}
//interface CallBackItemType {
//    fun onClickItem(selectedItem: IdAndName)
//}
//interface CallBackIdType {
//    fun onClickItem(ID: Int?,position:Int)
//}