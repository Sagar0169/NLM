package mission.vatsalya.utilities;

public class CONSTANTS {

    public static boolean isDebug = true;
//    public static String BASE_URL = "http://134.209.222.136/hrms_dev/api/rest/";
    public static String BASE_URL = "http://134.209.222.136:86/api/rest/";
}


