package mission.vatsalya.utilities;

public class PrefEntities {
    public static final String USER_DETAILS = "user_details";
    public static final String TOKEN = "token";
    public static final String selected_language = "selected_language";
    public static final String ADDRESS = "address";
    public static final String ADDRESS_ID = "address_ID";
    public static final String LAT = "lat";
    public static final String LONG = "long";
}
