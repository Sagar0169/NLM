package com.udid.module


import android.content.Context
import com.udid.repository.Repository
import com.udid.services.MyService
import com.udid.services.ServiceGenerator
import com.udid.utilities.UDID
import dagger.Provides
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class MyServiceModule {
    @Provides
    @Singleton
    fun provideMyService(): MyService {
        return ServiceGenerator.createService(MyService::class.java)
    }

    @Provides
    @Singleton
    fun provideRepository(api: MyService,
                          apiLogin: MyService
    ): Repository {
        return Repository(api, apiLogin)
    }

    @Provides
    @Singleton
    fun provideAppContext(context:Context): UDID {
        return context as UDID
    }


}